const products=[
{id:'JACK-001',name:'JACK Premium T-Shirt',brand:'JACK',price:799,img:'./product-1.png'},
{id:'GET-001',name:'GETZED Signature T-Shirt',brand:'GETZED',price:1019,img:'./product-2.png'},
{id:'JACK-002',name:'JACK Collection T-Shirt',brand:'JACK',price:809,img:'./product-3.png'},
{id:'GET-002',name:'GETZED T-Shirt',brand:'GETZED',price:899,img:'./product-4.png'},
{id:'JACK-003',name:'JACK Fresh Collection',brand:'JACK',price:849,img:'./product-5.png'}
];
function renderProducts(id='productGrid'){const row=document.getElementById(id);if(!row)return;row.innerHTML=products.map(p=>`<article class="card"><div class="pic"><img src="${p.img}" alt="${p.name}"></div><div class="body"><span class="tag">${p.brand}</span><h3>${p.name}</h3><div class="price">₹${p.price.toLocaleString('en-IN')}</div><button class="add" onclick="addCart('${p.id}')">Add to Cart</button></div></article>`).join('')}
function addCart(id){let cart=Number(localStorage.getItem('rg_cart')||0)+1;localStorage.setItem('rg_cart',cart);alert('Added to cart. Items: '+cart)}
